import knex from 'knex'
// const knex = require('knex')
const knexdb = knex({
client: 'mysql2',
connection: {
host: '127.0.0.1',
port: 3306,
user: 'aluno',
password: 'senacrs',
database: 'GFtool',
}
});
export default knexdb
// module.exports = {
//     knexdb
// }