import express from 'express'
import knexdb from './knex.js'
import cors from 'cors'

const app = express()
const port = 3000

app.use(express.json())
app.use(cors())

app.get('/GF/TB', async (req, res) => {
    const TBitem = await knexdb('TBtable').select('*');
    res.json(TBitem);  // Retorna diretamente um array de objetos
})

app.post('/GF/TB', async (req,res) =>{
    // INSERT INTO diretor(nome) VALUES ('');

    const { valor } = req.body;
    const { titulo } = req.body;
    const { tipo } = req.body;

    const novoTB = await knexdb('TBtable').insert({ valor, titulo, tipo })

    res.send('Conta Frequente adicionada')
})
app.get('/GF/OB', async (req, res) => {
    const OBitem = await knexdb('OCtable').select('*');
    res.json(OBitem);  // Retorna diretamente um array de objetos
})

app.post('/GF/OB', async (req,res) =>{
    // INSERT INTO diretor(nome) VALUES ('');

    const { valor } = req.body;
    const { titulo } = req.body;
    const { tipo } = req.body;

    const novoOB = await knexdb('OCtable').insert({ valor, titulo, tipo })

    res.send('Conta Frequente adicionada')
})

app.listen(port, () => {
console.log(`Example app listening on port ${port}`)
})