create database if not exists GFtool;
use GFtool;

-- tabela para o painel TimedBill
create table TBtable (
	id int auto_increment primary key,
    valor numeric(10, 2) not null,
    titulo varchar(60),
    tipo char(1) not null check(tipo in ('d', 'g'))
    -- 'd' para despesa, 'g' para ganho
);

-- tabela para o painel OccasionalBill
create table OCtable (
	id int auto_increment primary key,
    valor numeric(10, 2) not null,
    titulo varchar(60),
    tipo char(1) not null check(tipo in ('d', 'g', 'p'))
    -- 'd' para despesa, 'g' para ganho, 'p' para projeção (despesa em TBtable)
);

-- tabela para o painel Lembretes Rapidos
create table Lembretes (
	id int auto_increment primary key,
    titulo varchar(60) not null,
    descricao varchar(250),
    valor numeric(10, 2),
    tipo char(1) check(tipo in ('d', 'g', 'p'))
    -- 'd' para despesa, 'g' para ganho, 'p' para projeção (despesa em TBtable)
);